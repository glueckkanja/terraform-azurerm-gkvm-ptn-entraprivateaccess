Configuration InstallEntraPrivateAccess {
    param (
        [Parameter(Mandatory)]
        [string] $KeyVaultName,
        [Parameter(Mandatory)]
        [string] $SecretNameTenantId,
        [Parameter(Mandatory)]
        [string] $SecretNameAccessToken,
        [string] $TempPath = "C:\temp",
        [string] $ConnectorUrl = "https://download.msappproxy.net/Subscription/d3c8b69d-6bf7-42be-a529-3fe9c2e70c90/Connector/DownloadConnectorInstaller",
        [string] $ConnectorInstallPath = "C:\Program Files\Microsoft Entra private network connector"
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName Az.Accounts -ModuleVersion 2.10.4
    Import-DscResource -ModuleName Az.KeyVault -ModuleVersion 4.4.0

    File TempDirectory {
        Type = "Directory"
        DestinationPath = $TempPath
        Ensure = "Present"
    }

    Script GetKeyVaultSecrets {
        GetScript = {
            @{ Result = $false }
        }
        TestScript = {
            $tenantIdExists = Test-Path -Path "$using:TempPath\tenantId.txt"
            $tokenExists = Test-Path -Path "$using:TempPath\accessToken.txt"
            return ($tenantIdExists -and $tokenExists)
        }
        SetScript = {
            try {
                Connect-AzAccount -Identity

                # Get TenantId
                $tenantIdSecret = Get-AzKeyVaultSecret -VaultName $using:KeyVaultName -Name $using:SecretNameTenantId
                $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($tenantIdSecret.SecretValue)
                $tenantId = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
                Set-Content -Path "$using:TempPath\tenantId.txt" -Value $tenantId -Force

                # Get Access Token
                $tokenSecret = Get-AzKeyVaultSecret -VaultName $using:KeyVaultName -Name $using:SecretNameAccessToken
                $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($tokenSecret.SecretValue)
                $token = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
                Set-Content -Path "$using:TempPath\accessToken.txt" -Value $token -Force
            }
            catch {
                Write-Error "Failed to retrieve secrets: $_"
                throw
            }
        }
        DependsOn = "[File]TempDirectory"
    }

    Script InstallConnector {
        GetScript = {
            @{ Result = (Test-Path -Path "$using:ConnectorInstallPath\RegisterConnector.ps1") }
        }
        TestScript = {
            Test-Path -Path "$using:ConnectorInstallPath\RegisterConnector.ps1"
        }
        SetScript = {
            try {
                $installerPath = "$using:TempPath\MicrosoftEntraPrivateNetworkConnectorInstaller.exe"
                
                # Download installer if not exists
                if (-not (Test-Path $installerPath)) {
                    Invoke-WebRequest -Uri $using:ConnectorUrl -OutFile $installerPath
                }

                # Install connector
                Start-Process -FilePath $installerPath -ArgumentList "REGISTERCONNECTOR=`"false`" /q" -Wait

                # Create readme file
                $readmePath = "$using:TempPath\ReadMe.txt"
                @"
---------------------------------------
Connector Binary is available in $using:TempPath folder
---------------------------------------
We will attempt to register with Auth Token you provided. More info about the connector registration success, look into output.txt file in $using:TempPath folder and/or the Event Logs in Event Viewer -> Windows -> Application
If the registration is successful, Please login to your Entra Portal to manage the Connector. You can find it under Global Secure Access -> Connectors -> Default
---------------------------------------
"@ | Set-Content -Path $readmePath
            }
            catch {
                Write-Error "Failed to install connector: $_"
                throw
            }
        }
        DependsOn = "[Script]GetKeyVaultSecrets"
    }

    Script RegisterConnector {
        GetScript = {
            @{ Result = $false }
        }
        TestScript = {
            # Always run registration to ensure proper configuration
            return $false
        }
        SetScript = {
            try {
                $tenantId = Get-Content "$using:TempPath\tenantId.txt"
                $accessToken = Get-Content "$using:TempPath\accessToken.txt"
                
                Start-Transcript -Path "$using:TempPath\output.txt"
                $SecureToken = $accessToken | ConvertTo-SecureString -AsPlainText -Force
                
                & "$using:ConnectorInstallPath\RegisterConnector.ps1" `
                    -modulePath "$using:ConnectorInstallPath\Modules\" `
                    -moduleName "MicrosoftEntraPrivateNetworkConnectorPSModule" `
                    -Authenticationmode Token `
                    -Token $SecureToken `
                    -TenantId $tenantId `
                    -Feature ApplicationProxy
                
                Stop-Transcript
            }
            catch {
                Write-Error "Failed to register connector: $_"
                throw
            }
        }
        DependsOn = "[Script]InstallConnector"
    }
}